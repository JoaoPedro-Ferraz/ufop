#include <stdio.h>
#include <stdlib.h>
#include "leituraArquivo.h"
//#include "ordenacao.h"
#include "IBDVC.h"

int main(int argc, char *argv[]) {
    //Verificacao quantidade de arqumentos
    if(argc != 2) {
        printf("Quantidade de argumentos invalida!\n");
        exit(EXIT_FAILURE);
    }
    startIntercalacao(argv[1]);
    return 0;
}