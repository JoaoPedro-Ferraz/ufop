#ifndef IBDVC_H 
#define IBDVC_H

#include "leituraArquivo.h"

// Constante para numero de fitas
#define NUM_FITAS 40

// Funcoes
void startIntercalacao(char *); // Inicia a intercalacao

#endif // IBDVC_H
