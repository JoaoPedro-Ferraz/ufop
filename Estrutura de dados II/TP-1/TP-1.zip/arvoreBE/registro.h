
#ifndef REGISTRO_H
#define REGISTRO_H

typedef struct {
    int chave;
}TipoRegistro;

#endif //REGISTRO_H