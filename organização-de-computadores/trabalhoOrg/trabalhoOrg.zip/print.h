#ifndef PRINT_h
#define PRINT_h

void printSoma(int, int, int);
void printsubtracao(int, int, int);
void printMultiplicacao(int, int, int);
void printDivisao(int, int, int);
void printFatorial(int, int);
void printFibonacci(int, int);
void printMdc(int,int);
void printMmc(int, int);
void printSet(int, int);
void printGet(int, int);

#endif //PRINT_H