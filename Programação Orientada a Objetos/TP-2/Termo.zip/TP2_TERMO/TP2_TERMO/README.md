TERMO - Jogo (Wordle) em Java (Swing)
====================================

Estrutura do projeto
- src/com/termo/*.java   : código fonte principal
- termo-stats.txt        : arquivo de estatísticas (é criado ao executar)
- palavras.txt           : (não incluído; forneça o caminho ao executar)

Compilação e execução (linha de comando)
1) Compile:
   mkdir -p bin
   javac -d bin src/com/termo/*.java

2) Execute (providenciando o arquivo de palavras):
   java -cp bin com.termo.Main /caminho/para/palavras.txt

Observações
- O arquivo de palavras deve conter uma palavra por linha, com 5 letras cada.
- O programa salva estatísticas simples em termo-stats.txt no diretório de execução.
- Interface simples em Swing: insira palavras de 5 letras, clique em Enviar.
