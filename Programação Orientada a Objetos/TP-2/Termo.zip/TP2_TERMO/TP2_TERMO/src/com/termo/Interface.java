package com.termo;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class Interface extends JFrame {
    // --- Constantes para cores e estados ---
    private static final Color COR_CORRETO = new Color(0x6aaa64);
    private static final Color COR_PRESENTE = new Color(0xc9b458);
    private static final Color COR_AUSENTE = new Color(0x787c7e);
    private static final Color COR_PADRAO_TECLA = new Color(0xd3d6da);
    private static final Color COR_BORDA_CELULA = new Color(0x878a8c);
    
    private enum EstadoTecla {
        NAO_USADA(0), AUSENTE(1), PRESENTE(2), CORRETO(3);
        public final int prioridade;
        EstadoTecla(int prioridade) { this.prioridade = prioridade; }
    }

    private final Bancopalavras bancoPalavras;
    private Jogo jogo;
    private final Jogador jogadorLogado;
    private final JLabel[][] celulas = new JLabel[6][5];
    private int linhaAtual = 0;
    private int colunaAtual = 0;

    // Labels para exibir todas as estatísticas do jogador
    private final JLabel lblUsuario = new JLabel();
    private final JLabel lblJogos = new JLabel("Jogos: 0");
    private final JLabel lblVitorias = new JLabel("Vitórias: 0");
    private final JLabel lblDerrotas = new JLabel("Derrotas: 0");
    private final JLabel lblSeqVitorias = new JLabel("Seq. Vitórias: 0");
    private final JLabel lblMelhorSeq = new JLabel("Melhor Seq.: 0");
    private final JLabel lblTentativas = new JLabel("Tentativas restantes: 6");
    
    private final Map<Character, JButton> mapaTeclado = new HashMap<>();
    private final Map<Character, EstadoTecla> estadoTeclas = new HashMap<>();
    
    private final JButton btnEnter = new JButton("ENTER");
    private final JButton btnApagar = new JButton("APAGAR");

    public Interface(String caminhoPalavras, Jogador jogador) {
        super("TERMO - Jogo em Java (Swing)");
        
        this.jogadorLogado = jogador;
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        try {
            bancoPalavras = new Bancopalavras(caminhoPalavras);
        } catch (Exception e) {
            mostrarErroESair("Falha ao carregar o banco de palavras: " + e.getMessage());
            throw new RuntimeException(e);
        }

        add(criarPainelSuperior(), BorderLayout.NORTH);
        add(criarGradeCentral(), BorderLayout.CENTER);
        add(criarTecladoVirtual(), BorderLayout.SOUTH);
        
        pack();
        setLocationRelativeTo(null);
        setMinimumSize(getSize());
        
        novoJogo();
    }

    private JPanel criarPainelSuperior() {
        JPanel painel = new JPanel(new BorderLayout());
        
        JPanel painelInfo = new JPanel();
        painelInfo.setLayout(new BoxLayout(painelInfo, BoxLayout.Y_AXIS));

        lblUsuario.setText("Jogador: " + jogadorLogado.getNome());
        lblUsuario.setFont(new Font("Arial", Font.BOLD, 14));
        lblUsuario.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel painelEstatisticas = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        painelEstatisticas.add(lblJogos);
        painelEstatisticas.add(lblVitorias);
        painelEstatisticas.add(lblDerrotas);
        painelEstatisticas.add(lblSeqVitorias);
        painelEstatisticas.add(lblMelhorSeq);

        JPanel painelPartida = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        painelPartida.add(lblTentativas);
        
        painelInfo.add(lblUsuario);
        painelInfo.add(painelEstatisticas);
        painelInfo.add(painelPartida);
        painel.add(painelInfo, BorderLayout.WEST);

        JPanel painelControle = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnNovo = new JButton("Nova Partida");
        
        btnNovo.addActionListener(_ -> {
            int opcao = JOptionPane.showConfirmDialog(this,
                "Iniciar uma nova partida? A partida atual será perdida.",
                "Nova Partida", JOptionPane.YES_NO_OPTION);
            
            if (opcao == JOptionPane.YES_OPTION) {
                // Se o jogo já começou, a partida abandonada conta como derrota.
                if (linhaAtual > 0 || colunaAtual > 0) {
                    jogadorLogado.registrarDerrota();
                }
                novoJogo();
            }
        });

        JButton btnSair = new JButton("Sair");
        btnSair.addActionListener(_ -> {
            System.exit(0);
        });
        painelControle.add(btnNovo);
        painelControle.add(btnSair);
        painel.add(painelControle, BorderLayout.EAST);
        
        return painel;
    }

    private JPanel criarGradeCentral() {
        JPanel painelGrade = new JPanel(new GridLayout(6, 5, 4, 4));
        painelGrade.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        for (int linha = 0; linha < 6; linha++) {
            for (int coluna = 0; coluna < 5; coluna++) {
                JLabel label = new JLabel(" ", SwingConstants.CENTER);
                label.setOpaque(true);
                label.setBackground(Color.WHITE);
                label.setFont(new Font("Arial", Font.BOLD, 36));
                label.setBorder(new LineBorder(COR_BORDA_CELULA, 2));
                label.setPreferredSize(new Dimension(55, 55));
                celulas[linha][coluna] = label;
                painelGrade.add(label);
            }
        }
        return painelGrade;
    }

    private JPanel criarTecladoVirtual() {
        JPanel painelTeclado = new JPanel();
        painelTeclado.setLayout(new BoxLayout(painelTeclado, BoxLayout.Y_AXIS));
        painelTeclado.setBorder(BorderFactory.createEmptyBorder(10, 10, 15, 10));

        String[] linha1 = {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"};
        String[] linha2 = {"A", "S", "D", "F", "G", "H", "J", "K", "L"};
        String[] linha3 = {"Z", "X", "C", "V", "B", "N", "M"};

        JPanel painelLinha1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
        JPanel painelLinha2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
        JPanel painelLinha3 = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
        
        for (String s : linha1) { painelLinha1.add(criarBotaoLetra(s)); }
        for (String s : linha2) { painelLinha2.add(criarBotaoLetra(s)); }
        for (String s : linha3) { painelLinha3.add(criarBotaoLetra(s)); }

        btnApagar.setFont(new Font("Arial", Font.BOLD, 12));
        btnApagar.setPreferredSize(new Dimension(90, 50)); 
        btnApagar.setBackground(COR_PADRAO_TECLA);
        btnApagar.setForeground(Color.BLACK);
        btnApagar.setFocusPainted(false);
        btnApagar.addActionListener(_ -> apagarLetra());
        
        btnEnter.setFont(new Font("Arial", Font.BOLD, 12));
        btnEnter.setPreferredSize(new Dimension(90, 50));
        btnEnter.setBackground(COR_PADRAO_TECLA);
        btnEnter.setForeground(Color.BLACK);
        btnEnter.setFocusPainted(false);
        btnEnter.addActionListener(_ -> enviarPalpite());

        painelLinha3.add(btnApagar);
        painelLinha3.add(btnEnter);

        painelTeclado.add(painelLinha1);
        painelTeclado.add(Box.createVerticalStrut(5));
        painelTeclado.add(painelLinha2);
        painelTeclado.add(Box.createVerticalStrut(5));
        painelTeclado.add(painelLinha3);

        return painelTeclado;
    }

    private JButton criarBotaoLetra(String letra) {
        JButton btn = new JButton(letra);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(43, 50));
        btn.setBackground(COR_PADRAO_TECLA);
        btn.setForeground(Color.BLACK);
        btn.setBorder(BorderFactory.createEmptyBorder());
        btn.setFocusPainted(false);
        btn.setMargin(new Insets(0, 0, 0, 0));
        btn.addActionListener(_ -> adicionarLetra(letra));
        
        char charLetra = letra.charAt(0);
        mapaTeclado.put(charLetra, btn);
        estadoTeclas.put(charLetra, EstadoTecla.NAO_USADA);
        
        return btn;
    }
    
    private void adicionarLetra(String letra) {
        if (colunaAtual < 5 && linhaAtual < 6) {
            celulas[linhaAtual][colunaAtual].setText(letra);
            celulas[linhaAtual][colunaAtual].setForeground(Color.BLACK);
            colunaAtual++;
        }
    }
    
    private void apagarLetra() {
        if (colunaAtual > 0) {
            colunaAtual--;
            celulas[linhaAtual][colunaAtual].setText(" ");
        }
    }

    private void enviarPalpite() {
        if (colunaAtual != 5) {
            JOptionPane.showMessageDialog(this, "Palavra incompleta! Digite 5 letras.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        StringBuilder palpiteBuilder = new StringBuilder();
        for (int coluna = 0; coluna < 5; coluna++) {
            palpiteBuilder.append(celulas[linhaAtual][coluna].getText());
        }
        
        String palpite = palpiteBuilder.toString().toLowerCase();
        
        if (!bancoPalavras.contem(palpite)) {
            JOptionPane.showMessageDialog(this, "Palavra não encontrada no banco de palavras.", "Entrada inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Jogo.EstadoLetra[] resultado = jogo.avaliar(palpite);

        Map<Character, EstadoTecla> atualizacoesTeclado = new HashMap<>();
        for (int coluna = 0; coluna < 5; coluna++) {
            char letra = palpite.charAt(coluna);
            char letraMaiuscula = Character.toUpperCase(letra);
            
            EstadoTecla novoEstado;
            switch (resultado[coluna]) {
                case CORRETO:  novoEstado = EstadoTecla.CORRETO;  break;
                case PRESENTE: novoEstado = EstadoTecla.PRESENTE; break;
                default:       novoEstado = EstadoTecla.AUSENTE;  break;
            }

            EstadoTecla estadoExistente = atualizacoesTeclado.get(letraMaiuscula);
            if (estadoExistente == null || novoEstado.prioridade > estadoExistente.prioridade) {
                atualizacoesTeclado.put(letraMaiuscula, novoEstado);
            }
        }
        
        for (int coluna = 0; coluna < 5; coluna++) {
            switch (resultado[coluna]) {
                case CORRETO:
                    celulas[linhaAtual][coluna].setBackground(COR_CORRETO);
                    break;
                case PRESENTE:
                    celulas[linhaAtual][coluna].setBackground(COR_PRESENTE);
                    break;
                case AUSENTE:
                    celulas[linhaAtual][coluna].setBackground(COR_AUSENTE);
                    break;
            }
            celulas[linhaAtual][coluna].setForeground(Color.WHITE);
        }

        for (Map.Entry<Character, EstadoTecla> entrada : atualizacoesTeclado.entrySet()) {
            atualizarTecla(entrada.getKey(), entrada.getValue());
        }
        
        linhaAtual++;
        colunaAtual = 0;
        lblTentativas.setText("Tentativas restantes: " + jogo.getTentativasRestantes());

        if (palpite.equals(jogo.getPalavraSecreta())) {
            jogadorLogado.registrarVitoria();
            atualizarRotulosEstatisticas();
            JOptionPane.showMessageDialog(this, "Parabéns! Você descobriu a palavra: " + jogo.getPalavraSecreta().toUpperCase(), "Vitória", JOptionPane.INFORMATION_MESSAGE);
            novoJogo();
        } else if (jogo.getTentativasRestantes() <= 0) {
            jogadorLogado.registrarDerrota();
            atualizarRotulosEstatisticas();
            JOptionPane.showMessageDialog(this, "Fim de jogo! A palavra era: " + jogo.getPalavraSecreta().toUpperCase(), "Derrota", JOptionPane.INFORMATION_MESSAGE);
            novoJogo();
        }
    }
    
    private void atualizarTecla(char letra, EstadoTecla novoEstado) {
        char letraMaiuscula = Character.toUpperCase(letra);
        EstadoTecla estadoAtual = estadoTeclas.get(letraMaiuscula);
        
        if (estadoAtual == null || novoEstado.prioridade > estadoAtual.prioridade) {
            estadoTeclas.put(letraMaiuscula, novoEstado);
            
            JButton btn = mapaTeclado.get(letraMaiuscula);
            if (btn != null) {
                btn.setForeground(Color.WHITE);
                switch (novoEstado) {
                    case CORRETO: 
                        btn.setBackground(COR_CORRETO); 
                        break;
                    case PRESENTE: 
                        btn.setBackground(COR_PRESENTE); 
                        break;
                    case AUSENTE: 
                        btn.setBackground(COR_AUSENTE);
                        btn.setEnabled(false);
                        break;
                    default: 
                        btn.setBackground(COR_PADRAO_TECLA);
                        btn.setForeground(Color.BLACK);
                        break;
                }
            }
        }
    }

    private void novoJogo() {
        for (int linha = 0; linha < 6; linha++) {
            for (int coluna = 0; coluna < 5; coluna++) {
                celulas[linha][coluna].setText(" ");
                celulas[linha][coluna].setBackground(Color.WHITE);
                celulas[linha][coluna].setForeground(Color.BLACK);
            }
        }
        
        for (Character key : mapaTeclado.keySet()) {
            JButton btn = mapaTeclado.get(key);
            btn.setBackground(COR_PADRAO_TECLA);
            btn.setForeground(Color.BLACK);
            btn.setEnabled(true);
            estadoTeclas.put(key, EstadoTecla.NAO_USADA);
        }
        
        linhaAtual = 0;
        colunaAtual = 0;
        String secreta = bancoPalavras.proximaSecreta();
        jogo = new Jogo(secreta);
        lblTentativas.setText("Tentativas restantes: " + jogo.getTentativasRestantes());
        atualizarRotulosEstatisticas();
    }

    private void atualizarRotulosEstatisticas() {
        Estatisticas est = jogadorLogado.getEstatisticas();
        lblJogos.setText("Jogos: " + est.getJogos());
        lblVitorias.setText("Vitórias: " + est.getVitorias());
        lblDerrotas.setText("Derrotas: " + est.getDerrotas());
        lblSeqVitorias.setText("Seq. Vitórias: " + jogadorLogado.getSequenciaVitoriasAtual());
        lblMelhorSeq.setText("Melhor Seq.: " + jogadorLogado.getMelhorSequencia());
    }

    private void mostrarErroESair(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Erro", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }
}