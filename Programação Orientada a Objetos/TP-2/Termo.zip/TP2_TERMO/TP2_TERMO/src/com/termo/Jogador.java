package com.termo;

// Classe foi simplificada para não armazenar mais a senha.
public class Jogador {
    private final String nome;
    private final Estatisticas estatisticas;
    private int sequenciaVitoriasAtual;
    private int melhorSequencia;

    public Jogador(String nome) {
        this.nome = nome;
        this.estatisticas = new Estatisticas();
        this.sequenciaVitoriasAtual = 0;
        this.melhorSequencia = 0;
    }

    // Construtor para carregar dados de um arquivo (sem senha)
    public Jogador(String nome, int jogos, int vitorias, int derrotas, int seqAtual, int melhorSeq) {
        this.nome = nome;
        this.estatisticas = new Estatisticas(jogos, vitorias, derrotas);
        this.sequenciaVitoriasAtual = seqAtual;
        this.melhorSequencia = melhorSeq;
    }

    public String getNome() { return nome; }
    public Estatisticas getEstatisticas() { return estatisticas; }
    public int getSequenciaVitoriasAtual() { return sequenciaVitoriasAtual; }
    public int getMelhorSequencia() { return melhorSequencia; }

    public void registrarVitoria() {
        estatisticas.registrarVitoria();
        sequenciaVitoriasAtual++;
        if (sequenciaVitoriasAtual > melhorSequencia) {
            melhorSequencia = sequenciaVitoriasAtual;
        }
    }

    public void registrarDerrota() {
        estatisticas.registrarDerrota();
        sequenciaVitoriasAtual = 0;
    }

    // Formato CSV sem senha
    public String paraLinhaCsv() {
        return String.format("%s,%d,%d,%d,%d,%d",
            nome,
            estatisticas.getJogos(), estatisticas.getVitorias(), estatisticas.getDerrotas(),
            sequenciaVitoriasAtual, melhorSequencia);
    }

    // Leitura de CSV sem senha
    public static Jogador daLinhaCsv(String linha) {
        String[] partes = linha.split(",");
        if (partes.length < 6) return null;
        try {
            return new Jogador(partes[0], Integer.parseInt(partes[1]), Integer.parseInt(partes[2]),
                Integer.parseInt(partes[3]), Integer.parseInt(partes[4]), Integer.parseInt(partes[5]));
        } catch (NumberFormatException e) {
            return null;
        }
    }
}