package com.termo;

import java.util.*;

public class Jogo {
    public enum EstadoLetra { CORRETO, PRESENTE, AUSENTE }

    private final String palavraSecreta;
    private int tentativasRestantes = 6;
    private final List<String> palpites = new ArrayList<>();

    public Jogo(String palavraSecreta) {
        this.palavraSecreta = palavraSecreta.toLowerCase();
    }

    public String getPalavraSecreta() {
        return palavraSecreta;
    }

    public int getTentativasRestantes() {
        return tentativasRestantes;
    }

    public boolean isTerminado() {
        return tentativasRestantes <= 0;
    }

    /**
     * Avalia um palpite e retorna um array de EstadoLetra para as 5 letras.
     * Também decrementa tentativasRestantes se o palpite não estiver correto.
     */
    public EstadoLetra[] avaliar(String palpite) {
        palpite = palpite.toLowerCase();
        EstadoLetra[] resultado = new EstadoLetra[5];
        char[] letrasSecretas = palavraSecreta.toCharArray();
        char[] letrasPalpite = palpite.toCharArray();

        // Primeira passagem: marca letras corretas e reduz contagens
        int[] contagens = new int[26];
        for (char letra : letrasSecretas) {
            contagens[letra - 'a']++;
        }
        for (int i = 0; i < 5; i++) {
            if (letrasPalpite[i] == letrasSecretas[i]) {
                resultado[i] = EstadoLetra.CORRETO;
                contagens[letrasPalpite[i] - 'a']--;
            }
        }
        // Segunda passagem: marca presentes/ausentes
        for (int i = 0; i < 5; i++) {
            if (resultado[i] == EstadoLetra.CORRETO) continue;
            char letraPalpite = letrasPalpite[i];
            int indice = letraPalpite - 'a';
            if (indice < 0 || indice >= 26) {
                resultado[i] = EstadoLetra.AUSENTE;
            } else if (contagens[indice] > 0) {
                resultado[i] = EstadoLetra.PRESENTE;
                contagens[indice]--;
            } else {
                resultado[i] = EstadoLetra.AUSENTE;
            }
        }

        palpites.add(palpite);
        if (!palpite.equals(palavraSecreta)) {
            tentativasRestantes--;
        } else {
            tentativasRestantes = 0; // jogo vencido -> marca como terminado
        }
        return resultado;
    }

    public List<String> getPalpites() {
        return Collections.unmodifiableList(palpites);
    }
}