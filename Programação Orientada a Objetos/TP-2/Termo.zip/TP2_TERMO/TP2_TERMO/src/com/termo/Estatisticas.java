package com.termo;

// Agora esta classe apenas armazena os contadores básicos.
public class Estatisticas {
    private int jogos;
    private int vitorias;
    private int derrotas;

    public Estatisticas() {
        this.jogos = 0;
        this.vitorias = 0;
        this.derrotas = 0;
    }

    public Estatisticas(int jogos, int vitorias, int derrotas) {
        this.jogos = jogos;
        this.vitorias = vitorias;
        this.derrotas = derrotas;
    }

    public void registrarVitoria() {
        jogos++;
        vitorias++;
    }

    public void registrarDerrota() {
        jogos++;
        derrotas++;
    }

    public int getJogos() { return jogos; }
    public int getVitorias() { return vitorias; }
    public int getDerrotas() { return derrotas; }
}