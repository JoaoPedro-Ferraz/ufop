package com.termo;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Bancopalavras {
    private final List<String> palavras = new ArrayList<>();
    private final Random aleatorio = new Random();
    private final Set<String> palavrasUsadas = new HashSet<>();

    public Bancopalavras(String caminhoArquivo) throws IOException {
        List<String> linhas = Files.readAllLines(Paths.get(caminhoArquivo), StandardCharsets.UTF_8);
        for (String linha : linhas) {
            String palavra = linha.trim().toLowerCase();
            if (palavra.length() == 5) {
                palavras.add(palavra);
            }
        }
        if (palavras.isEmpty()) {
            throw new IOException("Banco de palavras vazio ou inválido: " + caminhoArquivo);
        }
    }

    public boolean contem(String palavra) {
        return palavras.contains(palavra.toLowerCase());
    }

    public String proximaSecreta() {
        if (palavrasUsadas.size() >= palavras.size()) {
            palavrasUsadas.clear(); // permite reutilização após esgotar todas
        }
        String selecionada;
        do {
            selecionada = palavras.get(aleatorio.nextInt(palavras.size()));
        } while (palavrasUsadas.contains(selecionada));
        palavrasUsadas.add(selecionada);
        return selecionada;
    }

    public void reiniciarPalavrasUsadas() {
        palavrasUsadas.clear();
    }

    public int tamanho() {
        return palavras.size();
    }
    
    public int palavrasRestantes() {
        return palavras.size() - palavrasUsadas.size();
    }
}