package com.termo;

import javax.swing.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    private static final Map<String, Jogador> jogadores = new HashMap<>();
    private static final String CAMINHO_JOGADORES = "jogadores.csv";

    public static void main(String[] args) {
        if (args.length < 1) {
            System.err.println("Uso: java -cp bin com.termo.Main <caminho-para-banco-de-palavras.txt>");
            System.exit(1);
        }
        final String caminhoPalavras = args[0];

        carregarJogadores();

        // Garante que os dados dos jogadores sejam salvos ao fechar o programa
        Runtime.getRuntime().addShutdownHook(new Thread(Main::salvarJogadores));

        Jogador jogadorLogado = executarLoginSimplificado();

        if (jogadorLogado != null) {
            SwingUtilities.invokeLater(() -> {
                Interface gui = new Interface(caminhoPalavras, jogadorLogado);
                gui.setVisible(true);
            });
        } else {
            System.exit(0); // Usuário cancelou
        }
    }

    private static Jogador executarLoginSimplificado() {
        while (true) {
            String nome = JOptionPane.showInputDialog(null, "Digite seu nome de usuário (ou crie um novo):", "Login de Jogador", JOptionPane.PLAIN_MESSAGE);

            if (nome == null) {
                return null; // Usuário fechou a janela ou clicou em cancelar
            }
            
            if (nome.trim().isEmpty() || nome.contains(",")) {
                JOptionPane.showMessageDialog(null, "Nome de usuário inválido. Não pode ser vazio ou conter vírgulas.", "Erro", JOptionPane.ERROR_MESSAGE);
                continue; // Pede o nome novamente
            }

            nome = nome.trim();
            Jogador jogador = jogadores.get(nome.toLowerCase());

            if (jogador == null) {
                // Se o jogador não existe, cria um novo
                jogador = new Jogador(nome);
                jogadores.put(nome.toLowerCase(), jogador);
                JOptionPane.showMessageDialog(null, "Bem-vindo, " + nome + "! Um novo perfil foi criado para você.");
            } else {
                JOptionPane.showMessageDialog(null, "Bem-vindo de volta, " + nome + "!");
            }
            
            return jogador;
        }
    }

    private static void carregarJogadores() {
        File arquivo = new File(CAMINHO_JOGADORES);
        if (!arquivo.exists()) return;
        try {
            List<String> linhas = Files.readAllLines(Paths.get(CAMINHO_JOGADORES), StandardCharsets.UTF_8);
            for (String linha : linhas) {
                Jogador jogador = Jogador.daLinhaCsv(linha);
                if (jogador != null) {
                    jogadores.put(jogador.getNome().toLowerCase(), jogador);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao carregar jogadores: " + e.getMessage());
        }
    }

    private static synchronized void salvarJogadores() {
        System.out.println("Salvando dados dos jogadores...");
        try (PrintWriter escritor = new PrintWriter(new OutputStreamWriter(new FileOutputStream(CAMINHO_JOGADORES), StandardCharsets.UTF_8))) {
            for (Jogador jogador : jogadores.values()) {
                escritor.println(jogador.paraLinhaCsv());
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar jogadores: " + e.getMessage());
        }
    }
}